﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3kl_1
{
    public partial class MoneyTrans : Form
    {
        public MoneyTrans()
        {
            InitializeComponent();
            ShowTransfers();
            AgentNameLbl.Text = Login.AName;
            DateLbl.Text = DateTime.Today.Day + "-" + DateTime.Today.Month + "-" + DateTime.Today.Year;

        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\info\my projects\egy_post_system(team_project)\3kl_1\DBforegyptpost1.mdf"";Integrated Security=True");

        private void ShowTransfers()
        {
            Con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select * from MoneyTrTbl", Con);
            SqlCommandBuilder Builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            TransferDGV.DataSource = ds.Tables[0];
            Con.Close();
        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (SNameTb.Text == "" || RNameTb.Text == "" || SPhoneTb.Text == "" || RPhoneTb.Text == "" || PinCodeTb.Text == "" || RAddressTb.Text == "" || SAddressTb.Text == "")
            {
                MessageBox.Show("Missing information");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("insert into MoneyTrTbl(TDate,SName,RName,SAdd,SPhone,RPhone,TrCode) values(@TD,@SN,@RN,@SA,@SP,@RP,@TC)", Con);
                    cmd.Parameters.AddWithValue("@TD", DateTime.Today.Date);
                    cmd.Parameters.AddWithValue("@SN", SNameTb.Text);
                    cmd.Parameters.AddWithValue("@RN", RNameTb.Text);
                    cmd.Parameters.AddWithValue("@SA", SAddressTb.Text);
                    cmd.Parameters.AddWithValue("@RA", RAddressTb.Text);
                    cmd.Parameters.AddWithValue("@SP", SPhoneTb.Text);
                    cmd.Parameters.AddWithValue("@RP", RPhoneTb.Text);
                    cmd.Parameters.AddWithValue("@TC", PinCodeTb.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Succsessful Transaction!!!");
                    Con.Close();
                    ShowTransfers();
                    //Reset();
                }

                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (SNameTb.Text == "" || RNameTb.Text == "" || SPhoneTb.Text == "" || RPhoneTb.Text == "" || PinCodeTb.Text == "" ||  SAddressTb.Text == "")
            {
                MessageBox.Show("Missing information");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("update MoneyTrTbl set TDate=@TD,SName=@SN,RName=@RN,SAdd=@SA,SPhone=@SP,RPhone=@RP,TrCode=@TC where TrNum=@TKey", Con);
                    cmd.Parameters.AddWithValue("@TD", DateTime.Today.Date);
                    cmd.Parameters.AddWithValue("@SN", SNameTb.Text);
                    cmd.Parameters.AddWithValue("@RN", RNameTb.Text);
                    cmd.Parameters.AddWithValue("@SA", SAddressTb.Text);
                    cmd.Parameters.AddWithValue("@RA", RAddressTb.Text);
                    cmd.Parameters.AddWithValue("@SP", SPhoneTb.Text);
                    cmd.Parameters.AddWithValue("@RP", RPhoneTb.Text);
                    cmd.Parameters.AddWithValue("@TC", PinCodeTb.Text);
                    cmd.Parameters.AddWithValue("@TKey", Key);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show(" Updated Transaction!!!");
                    Con.Close();
                    ShowTransfers();
                    //Reset();
                }

                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }
        int Key = 0;
        private void TransferDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            TrDate.Text = TransferDGV.SelectedRows[0].Cells[1].Value.ToString();
            SNameTb.Text = TransferDGV.SelectedRows[0].Cells[2].Value.ToString();
            RNameTb.Text = TransferDGV.SelectedRows[0].Cells[3].Value.ToString();
            SAddressTb.Text = TransferDGV.SelectedRows[0].Cells[4].Value.ToString();
            SPhoneTb.Text = TransferDGV.SelectedRows[0].Cells[5].Value.ToString();
            RPhoneTb.Text = TransferDGV.SelectedRows[0].Cells[6].Value.ToString();
            PinCodeTb.Text = TransferDGV.SelectedRows[0].Cells[7].Value.ToString();



            if (SNameTb.Text == "")
            {
                Key = 0;
            }
            else
            {
                Key = Convert.ToInt32(TransferDGV.SelectedRows[0].Cells[0].Value.ToString());
            }






        }

        private void RAddressTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void HometownCb_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Maindashbord obj = new Maindashbord();
            obj.Show();
            this.Hide();
        }
    }

}

