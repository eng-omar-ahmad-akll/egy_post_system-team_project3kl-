﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3kl_1
{
    public partial class Adminlogin : Form
    {
        public Adminlogin()
        {
            InitializeComponent();
        }

        private void Adminlogin_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {
            Login obj = new Login();
            obj.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (passwordTb.Text == "")
            {
                MessageBox.Show("Enter The Admin Password!!!");
            }else if (passwordTb.Text == "O3.A321")
            {
                Agents obj = new Agents();
                obj.Show();
                this.Hide();
            }else
            {
                MessageBox.Show("Wrong Passwor!!!");
            }
        }
    }
}
