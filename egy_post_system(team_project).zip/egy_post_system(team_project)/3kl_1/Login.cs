﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3kl_1
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\info\my projects\egy_post_system(team_project)\3kl_1\DBforegyptpost1.mdf"";Integrated Security=True");

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        public static string AName = "";
        private void button1_Click(object sender, EventArgs e)
        {
            Con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) from AgentTbl where AgName='" + UNameTb.Text + "' and AgPass='" + PsswordTb.Text + "'", Con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows[0][0].ToString() == "1")
            {
                AName = UNameTb.Text;
                Maindashbord obj = new Maindashbord();
                obj.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Wrong User Or The Passwor You Entered Is Wrong!!!");
            }
            Con.Close();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Adminlogin obj = new Adminlogin();
            obj.Show();
            this.Hide();
        }
        
        private void PsswordTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void UNameTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}
