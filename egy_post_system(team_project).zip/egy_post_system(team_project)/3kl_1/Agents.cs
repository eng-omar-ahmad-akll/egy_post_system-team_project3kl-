﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;

namespace _3kl_1
{
    public partial class Agents : Form
    {
        public Agents()
        {
            InitializeComponent();
            ShowAgents();
            DateLbl.Text = DateTime.Today.Day + "-" + DateTime.Today.Month + "-" + DateTime.Today.Year;

        }
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
        //

        private void ANameTb_TextChanged(object sender, EventArgs e)
        {

        }

        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\info\my projects\egy_post_system(team_project)\3kl_1\DBforegyptpost1.mdf"";Integrated Security=True");

        private void ShowAgents() {
            using (SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\info\my projects\egy_post_system(team_project)\3kl_1\DBforegyptpost1.mdf"";Integrated Security=True"))
            {
                Con.Open();
                SqlDataAdapter sda = new SqlDataAdapter("Select * from AgentTbl", Con);
                SqlCommandBuilder builder = new SqlCommandBuilder(sda);
                var ds = new DataSet();
                sda.Fill(ds);
                AgentsDGV.DataSource = ds.Tables[0];
                Con.Close();

            }
        }
        private void Reset()
        {
            ANameTb.Text = "";
            APhoneTb.Text = "";
            AddressTb.Text = "";
            APasswordTb.Text = "";

        }
        private void SaveBtn_Click(object sender, EventArgs e)
        {
            if (AddressTb.Text == "" || ANameTb.Text == "" || APasswordTb.Text == "" || APhoneTb.Text == "" || AgentCb.SelectedIndex == -1)
            {
                MessageBox.Show("Missing information");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("insert into AgentTbl(AgName,AgDOB,AgPhone,AgGen,AgAdd,AgPass) values(@AN,@AD,@AP,@AG,@AA,@Apa)", Con);
                    cmd.Parameters.AddWithValue("@AN", ANameTb.Text);
                    cmd.Parameters.AddWithValue("@AD", ADOB.Value.Date);
                    cmd.Parameters.AddWithValue("@AA", AddressTb.Text);
                    cmd.Parameters.AddWithValue("@AP", APhoneTb.Text);
                    cmd.Parameters.AddWithValue("@AG", AgentCb.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@APa", APasswordTb.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Agent Recorded!!!");
                    Con.Close();
                    ShowAgents();

                     Reset();
                }

                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }
        //

        private void ADate_ValueChanged(object sender, EventArgs e)
        {

        }

        private void EditBtn_Click(object sender, EventArgs e)
        {
            if (AddressTb.Text == "" & ANameTb.Text == "" & APasswordTb.Text == "" & APhoneTb.Text == "" & AgentCb.SelectedIndex == -1)
            {
                MessageBox.Show("Missing information");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("update AgentTbl set AgName=@AN,AgDOB=@AD,AgPhone=@AP,AgGen=@AG,AgAdd=@AA,AgPass=@Apa where AgNum=@AKey", Con);
                    cmd.Parameters.AddWithValue("@AN", ANameTb.Text);
                    cmd.Parameters.AddWithValue("@AD", ADOB.Value.Date);
                    cmd.Parameters.AddWithValue("@AA", AddressTb.Text);
                    cmd.Parameters.AddWithValue("@AP", APhoneTb.Text);
                    cmd.Parameters.AddWithValue("@AG", AgentCb.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@APa", APasswordTb.Text);
                    cmd.Parameters.AddWithValue("@AKey", Key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Agent Recorded!!!");
                    Con.Close();
                    ShowAgents();

                     Reset();
                }

                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }
        int Key = 0;
        private void CustDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)

        {
            
                    ANameTb.Text = AgentsDGV.SelectedRows[0].Cells[1].Value.ToString(); 

                    ADOB.Value = Convert.ToDateTime(AgentsDGV.SelectedRows[0].Cells[2].Value.ToString());
                    AddressTb.Text = AgentsDGV.SelectedRows[0].Cells[3].Value.ToString();
                    APhoneTb.Text = AgentsDGV.SelectedRows[0].Cells[4].Value.ToString();
                    AgentCb.SelectedItem = AgentsDGV.SelectedRows[0].Cells[5].Value.ToString();
                    APasswordTb.Text = AgentsDGV.SelectedRows[0].Cells[6].Value.ToString();
                    if (ANameTb.Text =="")


                    {
                        Key = 0;
                    }
                    else
                    {
                        Key = Convert.ToInt32(AgentsDGV.SelectedRows[0].Cells[0].Value.ToString());
                    }
                
                
            
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            if (Key == 0)
            {
                MessageBox.Show("select An Agent");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("delete from AgentTbl where AgNum = @AKey", Con);
                    cmd.Parameters.AddWithValue("@AKey", Key);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Agent Deleted!!!");
                    Con.Close();
                    ShowAgents();
                    Reset();
                }

                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            Login obj = new Login();
            obj.Show();
            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

 
