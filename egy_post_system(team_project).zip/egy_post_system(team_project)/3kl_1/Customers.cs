﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _3kl_1
{
    public partial class Customers: Form
    {
        public Customers()
        {
            InitializeComponent();
            ShowCustomers();
            DateLbl.Text = DateTime.Today.Day + "-" + DateTime.Today.Month + "-" + DateTime.Today.Year;
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\info\my projects\egy_post_system(team_project)\3kl_1\DBforegyptpost1.mdf"";Integrated Security=True");

        private void ShowCustomers()
        {
            Con.Open();
            SqlDataAdapter sda  =  new SqlDataAdapter("Select * from CustomerTbl", Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            CustDGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (custAddTb.Text == "" || custnameTb.Text == "" || custphoneTb.Text == "")
            {
                MessageBox.Show("Missing information");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("insert into CustomerTbl(CustName,CustDOB,CustPhone,CustAdd) values(@CN,@CD,@CP,@CA)", Con);
                    cmd.Parameters.AddWithValue("@CN", custnameTb.Text);
                    cmd.Parameters.AddWithValue("@CD", custDOB.Value.Date);
                    cmd.Parameters.AddWithValue("@CP", custphoneTb.Text);
                    cmd.Parameters.AddWithValue("@CA", custAddTb.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Customer Recorded!!!");
                    Con.Close();
                    ShowCustomers();
                    Reset();
                } 

                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }
        private void EditBtn_Click(object sender, EventArgs e)
        {
            if (custAddTb.Text == "" || custnameTb.Text == "" || custphoneTb.Text == "")
            {
                MessageBox.Show("Missing information");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("update CustomerTbl set CustName=@CN,CustDOB=@CD,CustPhone=@CP,CustAdd=@CA where CustNum=@CKey", Con);
                    cmd.Parameters.AddWithValue("@CN", custnameTb.Text);
                    cmd.Parameters.AddWithValue("@CD", custDOB.Value.Date);
                    cmd.Parameters.AddWithValue("@CP", custphoneTb.Text);
                    cmd.Parameters.AddWithValue("@CA", custAddTb.Text);
                    cmd.Parameters.AddWithValue("@CKey",Key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Customer Updated!!!");
                    Con.Close();
                    ShowCustomers();
                    Reset();
                }

                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }
        private void Reset()
        {
            custnameTb.Text = "";
            custphoneTb.Text = "";
            custAddTb.Text = "";
        }
        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            if (Key == 0 )
            {
                MessageBox.Show("select a customer");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("delete from CustomerTbl where CustNum = @CKey", Con);
                    cmd.Parameters.AddWithValue("@CKey", Key);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Customer Deleted!!!");
                    Con.Close();
                    ShowCustomers();
                    Reset();
                }

                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        int Key = 0;
        private void CustDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            custnameTb.Text = CustDGV.SelectedRows[0].Cells[1].Value.ToString();
            custDOB.Text = CustDGV.SelectedRows[0].Cells[2].Value.ToString();
            custphoneTb.Text = CustDGV.SelectedRows[0].Cells[3].Value.ToString();
            custAddTb.Text = CustDGV.SelectedRows[0].Cells[4].Value.ToString();
            if(custnameTb.Text == "")
            {
                Key = 0;
            }
            else
            {
                Key = Convert.ToInt32(CustDGV.SelectedRows[0].Cells[0].Value.ToString());
            }
        }

        private void custAddTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Maindashbord obj = new Maindashbord();
            obj.Show();
            this.Hide();
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }
    }
}
