﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3kl_1
{
    public partial class Delivery: Form
    {
        public Delivery()
        {
            InitializeComponent();
            ShowDelivery();
            GetAgentId();
            GetParcelId();
            AgentName.Text = Login.AName;
            DateLbl.Text = DateTime.Today.Day + "-" + DateTime.Today.Month + "-" + DateTime.Today.Year;


        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\info\my projects\egy_post_system(team_project)\3kl_1\DBforegyptpost1.mdf"";Integrated Security=True");

        private void ShowDelivery()
        {
            Con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select * from DeliveryTbl", Con);
            SqlCommandBuilder Builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            DeliveryDGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void GetAgentName()
        {
            Con.Open();
            string Query = "Select * from AgentTbl where AgNum=" + AgNumCB.SelectedValue.ToString() + "";
            SqlCommand cmd = new SqlCommand(Query, Con); DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                AgNameTb.Text = dr["AgName"].ToString();
            }
            Con.Close();
        }
        private void GetAgentId()
        {
            Con.Open();
            SqlCommand cmd = new SqlCommand("Select * from AgentTbl", Con);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("AgNum", typeof(int));
            dt.Load(rdr);
            AgNumCB.ValueMember = "AgNum";
            AgNumCB.DataSource = dt;
            Con.Close();
        }
        private void GetParcelId()
        {
            Con.Open();
            SqlCommand cmd = new SqlCommand("Select * from ParcelTbl", Con);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("PNum", typeof(int));
            dt.Load(rdr);
            ParNumCb.ValueMember = "PNum";
            ParNumCb.DataSource = dt;
            Con.Close();
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void Reset()
        {
            FeesTb.Text = "";
            AgNameTb.Text = "";
            AgNumCB.SelectedIndex= -1 ;
            ParNumCb.Text = "";

        }
        private void SaveBtn_Click(object sender, EventArgs e)
        {
            if (AgNumCB.SelectedIndex ==-1  || AgNameTb.Text == "" || FeesTb.Text == "" )
            {
                MessageBox.Show("Missing information");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("insert into DeliveryTbl(PrNum,DelDate,AgentNum,AgentName,DelFees) values(@PN,@DO,@ANum,@AName,@DelFees)", Con);
                    cmd.Parameters.AddWithValue("@PN", ParNumCb.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@DO", DelDate.Value.Date);
                    cmd.Parameters.AddWithValue("@ANum", AgNumCB.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@AName", AgNameTb.Text);
                    cmd.Parameters.AddWithValue("@DelFees", FeesTb.Text);
                   
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Packet Delivered!!!");
                    Con.Close();
                    ShowDelivery();

                    //Reset();
                }

                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void AgNumCB_SelectionChangeCommitted(object sender, EventArgs e)
        {
            GetAgentName();
        }

        private void DeliveryDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            Maindashbord obj = new Maindashbord();
            obj.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
